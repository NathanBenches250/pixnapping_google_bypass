package com.example.hide_overlay_test;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.activity.ComponentActivity;
import androidx.activity.EdgeToEdge;

public class MainActivity extends ComponentActivity {

    private TextView greeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.e("onCreate", "onCreate");
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        greeting = new TextView(this);
        greeting.setText("\n\n\n\n\n\n\n\t\tSecret!!");
        greeting.setFitsSystemWindows(true);

        setContentView(greeting);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("Hit", "ON PAUSE CALLED, SWITCH SCREEN!");
        greeting.setText("!");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e("Hit", "ON STOP CALLED, SWITCH SCREEN!");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("onResume", "onResume");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e("onStart", "onStart");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("onDestroy", "onDestroy");
    }
}
