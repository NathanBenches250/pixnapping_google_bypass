package com.example.hide_overlay_test

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.hide_overlay_test.ui.theme.Hide_overlay_testTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.e("onCreate", "onCreate");
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Hide_overlay_testTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "\n\n\n\n\n\n\n\t\tSecret!",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        Log.e("Hit", "ON PAUSE CALLED, SWITCH SCREEN!")

        setContent {
            Hide_overlay_testTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        Log.e("Hit", "ON STOP CALLED, SWITCH SCREEN!")
    }

    override fun onResume() {
        super.onResume();
        Log.e("onResume", "onResume");
    }

    override fun onStart() {
        super.onStart()
        Log.e("onStart", "onStart");
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.e("onDestroy", "onDestroy");
    }

}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "$name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Hide_overlay_testTheme {
        Greeting("blah blah blah")
    }
}
